package project2;

public interface Position {
    public int element();
}
